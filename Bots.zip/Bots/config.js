export default {
    max: 200,
    botNames: ['skibidy', 'toillet'],
    proxyType: 'http',
    url: 'https://raw.githubusercontent.com/elliottophellia/yakumo/master/results/http/global/http_checked.txt'
}